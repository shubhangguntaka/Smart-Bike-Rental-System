package com.sssit.bikerental;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BikeRentalBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(BikeRentalBackendApplication.class, args);
	}

}
